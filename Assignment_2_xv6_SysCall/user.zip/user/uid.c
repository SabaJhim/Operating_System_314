#include "kernel/types.h"
#include "user/user.h"


int main(int argc,char** argv){
        printf("My id is : %d",getuid());
        return 0;
}