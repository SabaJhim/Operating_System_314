struct stat;

// system calls
int fork(void); //done
int exit(int) __attribute__((noreturn)); //done
int wait(int*);//done
int pipe(int*);//done
int write(int, const void*, int); //done
int read(int, void*, int);//done
int close(int);//done
int kill(int);//done
int exec(const char*, char**);//done
int open(const char*, int);//done
int mknod(const char*, short, short); //done
int unlink(const char*);//done
int fstat(int fd, struct stat*);//done
int link(const char*, const char*);//done
int mkdir(const char*);//done
int chdir(const char*);//done
int dup(int);//done
int getpid(void);//done
char* sbrk(int);//done
int sleep(int);//done
int uptime(void);//done
int getuid(void);//done
int trace(int);
void info(void*);
int set_last_command(char* cmd);
void get_last_command(char* buf);

// ulib.c
int stat(const char*, struct stat*);
char* strcpy(char*, const char*);
void *memmove(void*, const void*, int);
char* strchr(const char*, char c);
int strcmp(const char*, const char*);
void fprintf(int, const char*, ...) __attribute__ ((format (printf, 2, 3)));
void printf(const char*, ...) __attribute__ ((format (printf, 1, 2)));
char* gets(char*, int max);
uint strlen(const char*);
void* memset(void*, int, uint);
void* malloc(uint);
void free(void*);
int atoi(const char*);
int memcmp(const void *, const void *, uint);
void *memcpy(void *, const void *, uint);
