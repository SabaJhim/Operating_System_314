#include "kernel/types.h"
#include "user/user.h"


int main(int argc,char** argv){
        printf("Hello world\n");
        char* s;
        s=malloc(10);
        gets(s,9);
        int num = atoi(s);

        printf("%d * %d = %d\n",num,num,num*num);
        return 0;
}