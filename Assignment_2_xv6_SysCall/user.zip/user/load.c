#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"




struct procInfo {
int activeProcess; // # of processes in RUNNABLE and RUNNING state
int totalProcess; // # of total possible processes
int memsize; // in bytes; summation of all active process
int totalMemSize; // in bytes; all available physical Memory
};


void childProcess(int allocationAmount) {
    printf("Child is created.\n");
    char *memory = malloc(allocationAmount);
    if (memory == 0) {
        printf("malloc failed\n");
        exit(1);
    }
    printf("Child allocated %d bytes.\n", allocationAmount);
    printf("Child going to sleep.\n");
    sleep(100);
    free(memory); 
    exit(0);
}




int main(int argc, char *argv[])
{       
    struct procInfo *s_info = malloc(sizeof(struct procInfo));
    if(argc != 3) {
        printf("Not enough arguments\n");
        return 1;
    }
    int childCount= atoi(argv[1]); 
    int allocationAmount= atoi(argv[2]);
    printf("Parent going to sleep.\n");
    for (int i = 0; i < childCount; i++) {
        int pid = fork();
        if (pid == 0) {
            childProcess(allocationAmount);
        }
        else{
                sleep(50);
        }
    }
    info(s_info);
    
    sleep(200);  
    printf("Parent wake up.\n");


    
    printf("Current System Information :\n");
    printf("Processes: %d /%d \n", s_info->activeProcess,s_info->totalProcess);
    double mem_size=s_info->memsize/(1024.0*1024.0);
    int whole_mem=(int)mem_size;
    int part_mem=(int)((mem_size-whole_mem)*1000);
    int total_mem=s_info->totalMemSize/(1024*1024);
    printf("RAM : %d.%d/%d (in MB)\n", whole_mem,part_mem,total_mem);
    exit(0);
}

