#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  if(argc < 3){
    printf("Usage: trace <syscall_num> <command>\n");
    exit(1);
  }

  int syscall_num = atoi(argv[1]);
  trace(syscall_num);  // Enable tracing for the given syscall number

  // Execute the command passed as arguments
  exec(argv[2], &argv[2]);
  printf("exec %s failed\n", argv[2]);
  exit(1);
}