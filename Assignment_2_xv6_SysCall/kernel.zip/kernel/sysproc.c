#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"





uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int uid=123;
uint64
sys_getuid(void){
  return uid;
}


uint64
sys_trace(void)
{
  int trace_mark;
  argint(0, &trace_mark);
  
  myproc()->trace_marker=trace_mark;
  return 0;
}





uint64 sys_info(void) {
    struct procInfo kernel_info;
    uint64 user_info;
    
    argaddr(0,&user_info);
  

  
    kernel_info.activeProcess = 0; 
    kernel_info.totalProcess = NPROC;
    kernel_info.memsize = 0; 

    acquire(&myproc()->lock);
    //used lock because of state
    for (struct proc *p = myproc(); p < &myproc()[NPROC]; p++) {
        if (p->state == RUNNING || p->state == RUNNABLE || p->state == SLEEPING) {
            kernel_info.activeProcess++;
            kernel_info.memsize += p->sz;
        }
    }
    release(&myproc()->lock);

    kernel_info.totalMemSize = PHYSTOP-KERNBASE;
    if (copyout(myproc()->pagetable, user_info, (char*)&kernel_info, sizeof(kernel_info)) < 0) {
      printf("Problem in processing\n");
        return -1;
    }

    return 0;
}

#define MAXLEN 100
char last_command[MAXLEN]; 
struct spinlock last_command_lock; 


uint64
sys_set_last_command(void)
{
    char cmd[MAXLEN];
    argstr(0, cmd, MAXLEN);
    safestrcpy(last_command, cmd,MAXLEN);
    return 0;
}

uint64
sys_get_last_command(void)
{      
        uint64 buf;
        initlock(&last_command_lock, "last_command_lock");
        acquire(&last_command_lock); 
        argaddr(0, &buf);
        if (copyout(myproc()->pagetable, buf, last_command, strlen(last_command) + 1) < 0) {
        return -1; // Error in copying
           }
        release(&last_command_lock);
        

    return 0;
}


