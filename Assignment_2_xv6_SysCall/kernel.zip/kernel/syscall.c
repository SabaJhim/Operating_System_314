#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "syscall.h"
#include "defs.h"
#include "stat.h"


// Fetch the uint64 at addr from the current process.
int
fetchaddr(uint64 addr, uint64 *ip)
{
  struct proc *p = myproc();
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    return -1;
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    return -1;
  return 0;
}

// Fetch the nul-terminated string at addr from the current process.
// Returns length of string, not including nul, or -1 for error.
int
fetchstr(uint64 addr, char *buf, int max)
{
  struct proc *p = myproc();
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    return -1;
  return strlen(buf);
}

static uint64
argraw(int n)
{
  struct proc *p = myproc();
  switch (n) {
  case 0:
    return p->trapframe->a0;
  case 1:
    return p->trapframe->a1;
  case 2:
    return p->trapframe->a2;
  case 3:
    return p->trapframe->a3;
  case 4:
    return p->trapframe->a4;
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
  *ip = argraw(n);
}

// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
  *ip = argraw(n);
}

// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
}

// Prototypes for the functions that handle system calls.
extern uint64 sys_fork(void);
extern uint64 sys_exit(void);
extern uint64 sys_wait(void);
extern uint64 sys_pipe(void);
extern uint64 sys_read(void);
extern uint64 sys_kill(void);
extern uint64 sys_exec(void);
extern uint64 sys_fstat(void);
extern uint64 sys_chdir(void);
extern uint64 sys_dup(void);
extern uint64 sys_getpid(void);
extern uint64 sys_sbrk(void);
extern uint64 sys_sleep(void);
extern uint64 sys_uptime(void);
extern uint64 sys_open(void);
extern uint64 sys_write(void);
extern uint64 sys_mknod(void);
extern uint64 sys_unlink(void);
extern uint64 sys_link(void);
extern uint64 sys_mkdir(void);
extern uint64 sys_close(void);
extern uint64 sys_getuid(void);
extern uint64 sys_trace(void);
extern uint64 sys_info(void);
extern uint64 sys_set_last_command(void);
extern uint64 sys_get_last_command(void);



// An array mapping syscall numbers from syscall.h
// to the function that handles the system call.
static uint64 (*syscalls[])(void) = {
[SYS_fork]    sys_fork,
[SYS_exit]    sys_exit,
[SYS_wait]    sys_wait,
[SYS_pipe]    sys_pipe,
[SYS_read]    sys_read,
[SYS_kill]    sys_kill,
[SYS_exec]    sys_exec,
[SYS_fstat]   sys_fstat,
[SYS_chdir]   sys_chdir,
[SYS_dup]     sys_dup,
[SYS_getpid]  sys_getpid,
[SYS_sbrk]    sys_sbrk,
[SYS_sleep]   sys_sleep,
[SYS_uptime]  sys_uptime,
[SYS_open]    sys_open,
[SYS_write]   sys_write,
[SYS_mknod]   sys_mknod,
[SYS_unlink]  sys_unlink,
[SYS_link]    sys_link,
[SYS_mkdir]   sys_mkdir,
[SYS_close]   sys_close,
[SYS_getuid]  sys_getuid,
[SYS_trace]   sys_trace,
[SYS_info]   sys_info,
[SYS_set_last_command]  sys_set_last_command,
[SYS_get_last_command]  sys_get_last_command,
};

const char *syscall_names[] = {
    "null",    // 0
    "fork",    // 1
    "exit",   // 2
    "wait",   // 3
    "pipe",    // 4
    "read",    // 5
    "kill",    // 6
    "exec",    // 7
    "fstat",   // 8
    "chdir",    // 9
    "dup",     // 10
    "getpid",  // 11
    "sbrk",    // 12
    "sleep",   // 13
    "uptime",  // 14
    "open",    // 15
    "write",   // 16
    "mknod",   // 17
    "unlink",  // 18
    "link",    // 19
    "mkdir",   // 20
    "close",   // 21
    "getuid",  // 22
    "trace"    // 23
};

int* get_syscall_args(int sys_num) {
    int *arr = kalloc();
    for (int i=0;i<6;i++){
        arr[i]=0;
    }
  //1->int
  //2->char*
  //3->uint64
  //0->void
    switch (sys_num) {
        case SYS_fork:
            return arr;
        case SYS_exit:
            arr[0]=1;
            return arr;
        case SYS_wait:
            arr[0]=3;
            return arr;
        case SYS_pipe:
            arr[0]=3;
            return arr;
        case SYS_read:
            arr[0]=1;
            arr[1]=3;
            arr[2]=1;
            return arr;
        case SYS_write:
            arr[0]=1;
            arr[1]=3;
            arr[2]=1;
            return arr;   
        case SYS_close:
            arr[0]=1;
            return arr;
          
        case SYS_exec:
            arr[0]=2;
            arr[1]=3;
            return arr;

        case SYS_open:
            arr[0]=2;
            arr[1]=1;
            return arr;
        case SYS_kill :
            arr[0]=1;
            return arr;
        case SYS_mknod :
            arr[0]=2;
            arr[1]=1;
            arr[2]=1;
            return arr;
        case SYS_unlink :
            arr[0]=2;
            return arr;
        case SYS_fstat :
             arr[0]=1;
             arr[1]=3;
             return arr;
        case SYS_link :
            arr[0]=2;
            arr[1]=2;
            return arr;
        case SYS_mkdir :
            arr[0]=2;
            return arr;
        case SYS_chdir :
            arr[0]=2;
            return arr;
        case SYS_dup :
            arr[0]=1;
            return arr;
        case SYS_getpid :
            return arr;
        case SYS_sbrk :
            arr[0]=1;
            return arr;
        case SYS_sleep :
            arr[0]=1;
            return arr;
        case SYS_uptime :
            return arr;
        case SYS_getuid :
            return arr; 
        case SYS_trace :
            arr[0]=1;
            return arr;
        default:
            return arr;
    }
}

void
syscall(void)
{
  int num;
  struct proc *p = myproc();

  int* array;
  int int_arg;
  char str_arg[100];
  char str_arg1[100];
  int flag=0;
  uint64 addr_arg;

  num = p->trapframe->a7;

  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    array=get_syscall_args(num);
    for(int i=0;i<6;i++){
      if(array[i]==2 && flag==0){
        argstr(i,str_arg,100);
        flag=1;
      }
      if(array[i]==2 && flag==1){
        argstr(i,str_arg1,100);
      }

    }

    p->trapframe->a0 = syscalls[num]();
    int return_val=p->trapframe->a0;

    if(num==p->trace_marker){
      acquire(&p->lock);
      //used lock because of pid
      printf("pid :  %d, syscall : %s ",p->pid,syscall_names[num]);
      release(&p->lock);
      for(int i=0;i<6;i++){
        if(array[i]==0 && i==0){
          printf("args: () ");
          break;
        }
      else if(array[i]==1 && i==0){
            argint(0, &int_arg);
            printf("args: (%d ", int_arg); 
      }
      else if(array[i]==2 && i==0){
        printf("args: (%s ", str_arg);
      }
      else if(array[i]==3 && i==0){
            argaddr(0, &addr_arg);
            printf( "args: (%p  ", (void*)addr_arg); 
      }
      else if(array[i]==1){
        argint(i, &int_arg);
        printf(", %d ", int_arg);
      }
      else if(array[i]==2 && flag==1){
        printf( ", %s ", str_arg);
        flag=2;
      }
      else if(array[i]==2 && flag==2){
        printf( ", %s ", str_arg1);
      }
      else if(array[i]==3){
        argaddr(i, &addr_arg);
        printf(", %p", (void*)addr_arg);
      }
      else if(array[i]==0 && i!=0){
      printf( " ) ");
        break;
      }
      else{
        break;
      }
    }
      printf("return : %d\n",return_val);
  }
} else {
    acquire(&p->lock);
    //used locking because of pid
    printf("%d %s: unknown syscall %d\n", p->pid, p->name, num);
    release(&p->lock);
    p->trapframe->a0 = -1;
  }
}
